package br.com.gustavo.footmarket.back_end;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
